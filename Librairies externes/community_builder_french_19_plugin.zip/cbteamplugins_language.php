<?php
/**
* Joomla/Mambo Community Builder
* @version $Id: cbteamplugins_language.php 2012-11-18 lavsteph$
* @package Community Builder
* @subpackage french Plugins Language file for CB 1.9
* @author forge.joomlapolis.com/projects/lan-cb-fr
* @copyright (C) 2005 - 2012 www.joomlapolis.com
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
*/

// ensure this file is being included by a parent file:
if ( ! ( defined('_VALID_CB' ) || defined('_JEXEC' ) || defined('_VALID_MOS' ) ) ) { die('Direct Access to this location is not allowed.' ); }

// 1.2 Stable:
// ProfileBook plugin : (new method : UTF8 encoding here):
CBTxt::addStrings( array(
'The file exceeds the maximum size of %s kilobytes' => 'Le fichier dépasse la taille maximum de %s kilobytes',
'Profile Book' => 'Livre d\'or du profil',
'Name' => 'Nom',
'Entry' => 'Article',
'Profile Book Description' => 'Description du livre d\'or',
'Created On : %s' => 'Créé le %s',
'Edited By %s On : %s' => 'Modifié le %2$s par %1$s',
'<br /><strong>[Notice: </strong><em>Last Edit by Site Moderator</em><strong>]</strong>' => '<br /><strong>[Nota : </strong><em>Dernière édition par le modérateur du site</em><strong>]</strong> ',
'Users Feedback:' => 'Commentaires des utilisateurs :',
'Edited by Site Moderator' => 'Modifié par le modérateur du site',
'Comments' => 'Commentaires',
'Name' => 'Nom',
'Email' => 'Courriel',
'Location' => 'Lieu',
'This user currently doesn\'t have any posts.' => 'Cet utilisateur n\'a pas de messages.',
'User Rating' => 'Évaluation de l\'utilisateur',
'Web Address' => 'Adresse du site Web',
'Submit Entry' => 'Soumettre l\'article',
'Update Entry' => 'Mettre à jour l\'article',
'Enable Profile Entries' => 'Activer les articles dans le profil',
'Auto Publish' => 'Auto-publication',
'Notify Me' => 'M\'avertir',
'Enable visitors to your profile to make comments about you and your profile.' => 'Permettre aux visiteurs de votre profil de faire des commentaires sur vous et votre profil.',
'Enable Auto Publish if you want entries submitted to be automatically approved and displayed on your profile.' => 'Activer l\'Auto-publication si vous voulez que les articles soient automatiquement approuvés et affichés sur votre profil.',
'Enable Notify Me if you would like to receive an email notification each time someone submits an entry.  This is recommended if you are not using the Auto Publish feature.' => 'Activer "M\'avertir" si vous souhaitez recevoir un courriel de notification à chaque fois que quelqu\'un soumet un article. Ceci est recommandé si vous n\'utilisez pas la fonction de publication automatique',
'Enable Profile Blog' => 'Activer le blog du profil',
'Enable Profile Wall' => 'Activer le mur du profil',
'Enable your blog on your profile.' => 'Activer votre blog sur votre profil.',
'Enable the wall on your profile so yourself and visitors can write on it.' =>'Activer le mur sur votre profil afin que vous et les visiteurs puissent écrire dessus.',
'Enable Notify Me if you\'d like to receive an email notification each time someone submits an entry. This is recommended if you are not using the Auto Publish feature.' => 'Activer la notification si vous souhaitez recevoir un courriel de notification à chaque fois que quelqu\'un envoie un article. Ceci est recommandé si vous n\'utilisez pas l\'auto-publication.',
'Bold' => 'Gras',
'Italic' => 'Italique',
'Underline' => 'Souligné',
'Quote' => 'Citation',
'Code' => 'Code',
'List' => 'Liste',
'List' => 'Liste',
'Image' => 'Image',
'Link' => 'Lien',
'Close' => 'Fermer',
'Color' => 'Couleur',
'Size' => 'Taille',
'Item' => 'Élément',
'Bold text: [b]text[/b]' => 'Texte en gras : [b]texte[/b]',
'Italic text: [i]text[/i]' => 'Texte en italique : [i]texte[/i]',
'Underline text: [u]text[/u]' => 'Texte souligné : [u]texte[/u]',
'Quoted text: [quote]text[/quote]' => 'Texte cité : [quote]texte[/quote]',
'Code display: [code]code[/code]' => 'Code affiché : [code]code[/code]',
'Unordered List: [ul] [li]text[/li] [/ul] - Hint: a list must contain List Items' => 'Liste non ordonnée : [ul] [li]texte[/li] [/ul] - Remarque : la liste doit contenir des éléments',
'Ordered List: [ol] [li]text[/li] [/ol] - Hint: a list must contain List Items' => 'Liste ordonnée : [ol] [li]texte[/li] [/ol] - Remarque : la liste doit contenir des éléments',
'Image: [img size=(01-499)]http://www.google.com/images/web_logo_left.gif[/img]' => 'Image: [img size=(01-499)]http://www.google.com/images/web_logo_left.gif[/img]',
'Link: [url=http://www.zzz.com/]This is a link[/url]' => 'Lien : [url=http://www.zzz.com/] Ceci est un lien [/url]',
'Close all open bbCode tags' => 'Fermez toutes les balises bbcode',
'Color: [color=#FF6600]text[/color]' => 'Couleur : [color=#FF6600]texte[/color]',
'Size: [size=1]text size[/size] - Hint: sizes range from 1 to 5' => 'Taille : [size=1]la taille du texte[/size] - Remarque : les tailles vont de 1 à 5',
'List Item: [li] list item [/li] - Hint: a list item must be within a [ol] or [ul] List' => 'Élément de liste : [li]élément de la liste[/li] - Remarque : un élément de liste doit être à l\'intérieur d\'un [ol] ou d\'un [ul]',
'Dimensions' => 'Dimensions',
'File Types' => 'Types de fichiers',
'Submit' => 'Envoyer',
'Preview' => 'Aperçu',
'Cancel' => 'Annuler',
'User Comments' => 'Commentaires de l\'utilisateur',
'Your Feedback' => 'Votre avis',
'Edit' => 'Modifier',
'Update' => 'Mettre à jour',
'Delete' => 'Supprimer',
'Publish' => 'Publier',
'Sign Profile Book' => 'Signer le livre d\'or',
'Give Feedback' => 'Donner un avis',
'Edit Feedback' => 'Modifier un avis',
'Un-Publish' => 'Dépublier',
'Not Published' => 'Non Publié',
'Color' => 'Couleur',
'Size' => 'Taille',
'Very Small' => 'Très petit',
'Small' => 'Petit',
'Normal' => 'Normal',
'Big' => 'Grand',
'Very Big' => 'Très grand',
'Close All Tags' => 'Fermer tous les tags',
'Standard' => 'Standard',
'Red' => 'Rouge',
'Purple' => 'Violet',
'Blue' => 'Bleu',
'Green' => 'Vert',
'Yellow' => 'Jaune',
'Orange' => 'Orange',
'Darkblue' => 'Bleu foncé',
'Gold' => 'Or',
'Brown' => 'Marron ',
'Silver' => 'Argent',
'You have received a new entry in your %s' => 'Vous avez reçu un nouvel article sur votre compte %s',
'%s has just submitted a new entry in your %s.' => '%s vient de soumettre un nouvel article sur votre compte %s.',
'An entry in your %s has just been updated' => 'Un article sur votre compte %s vient d\'être mis à jour',
'%s has just submitted an edited entry for %s in your %s.' => '%s vient de soumetre la modification d\'un article %s sur votre compte %s.',
"\n\nYour current setting is that you need to review entries in your %1\$s. Please login, review the new entry and publish if you agree. Direct access to your %1\$s:\n%2\$s\n" =>' \n\nVotre paramétrage actuel est de passer en revue les articles de votre %1\$s. Veuillez vous connecter le nouvel article, et le publier si vous êtes d\'accord. Accès direct à votre %1\$s : \n%2\$s\n',
"\n\nYour current setting is that new entries in your %1\$s are automatically published. To see the new entry, please login. You can then see the new entry and take appropriate action if needed. Direct access to your %1\$s:\n%2\$s\n" => '\n\nVotre paramétrage actuel est tel que les nouveaux articles sur votre compte %1\$s sont automatiquement publiés. Veuillez vous connecter pour voir le nouvel article. Vous pourrez alors prendre les mesures appropriées si nécessaire. Accès direct à votre %1\$s : \n%2\$s\n',
'Name is Required !' => 'Le nom est obligatoire !',
'Email Address is Required!' => 'L\'adresse courriel est obligatoire ! ',
'Comment is Required!' => 'Commentaire obligatoire ! ',
'User Rating is Required!' => 'L\'évaluation de l\'utilisateur est obligatoire ! ',
'You have not selected a User Rating. Do you really want to provide an Entry without User Rating?' => 'Vous n\'avez pas sélectionné d\'évaluation d\'utilisateur. Voulez-vous vraiment envoyer un article sans évaluation d\'utilisateur ?',
'Return Gesture'=> 'Geste en retour',
'Profile Rating' => 'Évaluation du profil',
'You have not selected your User Rating.' => 'Vous n\'avez pas sélectionné votre évaluation d\'utilisateur.',
'Would you like to give a User Rating?' => 'Voulez-vous évaluer cet utilisateur ?',
'Do you really want to delete permanently this Comment and associated User Rating ?' => 'Voulez-vous vraiment supprimer définitivement ce commentaire et les évaluations associées ?',
'You are about to edit somebody else\'s text as a site Moderator. This will be clearly noted. Proceed ?' => 'Vous êtes sur le point de modifier le texte de quelqu\'un en tant que modérateur. Cette action sera clairement indiquée. Continuer ? ',
'Hidden' => 'Masqué',
'Feedback from %s: ' => 'Commentaires de %s:',
'Poor' => 'Mauvais',
'Best' => 'Meilleur',
// 1.2:
'Vote %s star' => 'Vote %s étoile',
'Vote %s stars' => 'Vote %s étoiles',
'Cancel Rating' => 'Annuler l\'évaluation',
'Average Profile Rating by other users' => 'Moyenne de l\'évaluation du profil par les autres utilisateurs',
// 1.2.1:
'Title' => 'Titre',
'Title is Required!' => 'Le titre est obligatoire !',
'NEW' => 'Nouveau',
'Mark Read' => 'Marqué comme lu',
'Mark Unread' => 'Marqué comme non lu',
'You have %s new %s post' => 'Vous avez %s nouveau %s message',
'You have %s new %s posts' => 'Vous avez %s nouveaux %s messages',
'Add new blog entry' => 'Ajouter un article de blog',
'Wall entry' => 'Article du mur',
'Write on the wall' => 'Écrire sur le mur',
'Entry' => 'Article',
'Blog text' => 'Texte du blog',
'Save Blog Entry' => 'Enregistrer l\'article de blog',
'Video' => 'Video',
'Video: [video type=youtube]id[/video] - Hint: id is only the embedding id of the video' => 'Video: [video type=youtube]id[/video] Remarque : id est seulement l\'id d\'encapsulage de la video',
// module:
'%s added a new guestbook entry to %s' => '%s a ajouté un nouvel article au livre d\'or de %s',
'%s wrote a new blog "%s"' => '%s a écrit un nouveau blog "%s"',
'%s wrote a new blog' => '%s a écrit un nouveau blog',
'%s added a new wall entry to %s' => '%s a ajouté un nouvel article au mur de %s',
'%s added a new wall entry' => '%s a ajouté un nouvel article sur le mur',
'No entries have been made!' => 'Aucun article n\'a été saisi!',
// 1.2.2:
'Untranslated strings on this page' => 'Il y a des chaînes non traduites sur la page',
'Translations on this page' => 'Traductions présentes sur la page',
'English string' => 'Chaîne en Anglais',
'Translated string' => 'Chaîne traduite'
) );


// Profile Gallery plugin: (new method: UTF8 encoding here):
CBTxt::addStrings( array(
'CB Profile Gallery' => 'Galerie de profil CB',
'This tab contains a basic no-frills image Gallery for CB profiles' => 'Cet onglet contient une galerie d\'images basiques pour les profils CB',
'Current Items' => 'Articles en cours',
'Keeps track of number of stored items' => 'Garde la trace du nombre d\'articles stockés',
'Date of last update to Gallery items in this profile' => 'Date de la dernière mise à jour d\'article dans la galerie de ce profil',
'Last Update' => 'Dernière mise à jour',
'Enable Gallery' => 'Activer la galerie',
'Select Yes or No to turn-on or off the Gallery Tab' => 'Sélectionnez Oui ou Non pour afficher ou non l\'onglet de la galerie',
'Short Greeting' => 'Courte salutation',
'Enter a short greeting for your gallery viewers' => 'Saisissez un court message de bienvenue pour les visiteurs de votre galerie',
'Item Quota' => 'Quota d\'articles',
'The admin may use this to over-ride the default value of allowable items for each profile owner' => 'L\'administrateur peut utiliser ceci pour forcer la valeur par défaut du nombre d\'articles autorisé par profil',
'No Items published in this profile gallery' => 'Aucun article publié dans la galerie de ce profil',
'Title:' => 'Titre :',
'Description:' => 'Description :',
'Image File:' => 'Fichier image :',
'Submit New Gallery Entry' => 'Envoyer un nouvel article dans la galerie',
'Submit Gallery Entry' => 'Soumettre un article dans la galerie',
'A file must be selected via the Browse button' => 'Un fichier doit être sélectionné avec le bouton Parcourir',
'A gallery item title must be entered' => 'L\'article de galerie doit avoir un titre',
'Autopublish items' => 'Auto-publier les articles de galerie',
'Select Yes or No to autopublish or not newly uploaded gallery items' => 'Sélectionnez Oui ou Non pour autopublier ou non les articles récemment envoyés dans la galerie',
'Current Storage' => 'Stockage actuel',
'This field keeps track of the total size of all uploaded gallery items - like a quota usage field. Value is in bytes.' => 'Ce champ permet de suivre la taille totale de tous les articles envoyés dans la galerie (comme un champ de quota). La valeur est en octets.',
'Greetings - connections only viewing enabled' => 'Bienvenue - l\'affichage est activé seulement pour les relations directes',
'Sorry - connections only viewing enabled for this gallery that currently has %1$d items in it.' => 'Désolé - l\'affichage est activé seulement pour les relations directes pour cette galerie, qui comprend %1$d articles.',
'Automatically approve' => 'Approbation automatique',
'This value can be set by the admin to over-ride the gallery plugin backend default approval parameter' => 'Cette valeur peut être indiquée par l\'administrateur pour forcer le paramétrage d\'approbation par défaut de la galerie',
'Storage Quota (KB)' => 'Quota de stockage (KB)',
'This value can be set by the admin to over-ride the gallery plugin backend default user quota' => 'Cette valeur peut être spécifiée par l\'administrateur pour forcer le paramétrage de stockage par défaut de la galerie',
'Maximum allowable single upload size exceeded - gallery item rejected' => 'Dépassement de la taille maximale admissible pour un envoi - article de galerie rejeté',
'File extension not authorized' => 'Extension de fichier non autorisée',
/**
 * Parameters available for use in _pg_QuotaMessage language string
 * %1$d ~ Total count of items uploaded
 * %2$d ~ Maximum uploaded items allowed
 * %3$d ~ Total KB of uploaded items
 * %4$d ~ Maximum KB of uploaded items allowed
 * %5$d ~ Consumed storage percentage of uploaded items
 * %6$d ~ Free storage percentage of uploaded items
 * %7$d ~ Maximum single upload size
 */
' [Your current quota marks: %1$d/%2$d items %3$d/%4$d Kbytes (%5$d%% consumed - %6$d%% free)]' => '[ Votre quota actuel indique %1$d / %2$d articles %3$d / %4$d Ko (%5$d%% utilisé - %6$d%% disponible)]',
'This file would cause you to exceed you quota - gallery item rejected' => 'Ce fichier vous ferait dépasser votre quota - article de galerie rejeté',
'Access Mode' => 'Mode d\'accès',
'Select desirable access mode: Public access, Registered users only, Connected users only, REG-S for Registered-stealth, CON-S for Connections-stealth' => 'Sélectionnez le mode d\'accès souhaité : accès public, seulement pour les utilisateurs inscrits, seulement pour les utilisateurs en relation directe, REG-S pour les inscrits en mode invisible, CON-S pour les relations directes en mode invisible',
'Allow Public Access' => 'Autoriser l\'accès public',
'Allow Registered Access' => 'Autoriser l\'accès aux utilisateurs inscrits',
'Allow Connections Access' => 'Autoriser l\'accès aux utilisateurs en relation directe',
'Registered Stealth Access' => 'Accès invisible aux utilisateurs inscrits',
'Connections Stealth Access' => 'Accès invisible aux utilisateurs en relation directe',
'Display Format' => 'Format d\affichage',
'Select Display Format to apply for gallery viewing.' => 'Sélectionnez le format d\'affichage de la galerie.',
'Pictures gallery list format' => 'Format des listes d\'images de la galerie',
'File list format' => 'Format des listes de fichier',
'Picture gallery list lightbox format' => 'Format des aperçus des listes d\'images de la galerie',
'Gallery repository successfully created!' => 'Répertoire de galerie créé avec succès !',
'Gallery repository could not be created! Please notify system admin!' => 'Le répertoire de galerie n\'a pas pu être créé ! Veuillez en avertir l\'administrateur ! ',
'Image ToolBox failure! - Please notify system admin - ' => 'Erreur de la boîte à outils Image ! Veuillez en avertir l\'administrateur ! ',
'The file upload has failed! - Please notify your system admin!' => 'L\'envoi du fichier a échoué ! Veuillez en avertir l\'administrateur ! ',
/**
 * Parameters available for use in _pg_FileUploadSucceeded and _pg_FileUploadAndTnSucceeded language strings
 * %1$s ~ Name of uploaded file in user repository
 */
'The file %1$s has been successfully uploaded!' => 'Le fichier %1$s a été envoyé avec succès !',
'The file %1$s has been successfully uploaded and tn%1$s thumbnail created!' => 'Le fichier %1$s a été envoyé avec succès et la miniature tn%1$s créée !',
'Only Registered Members Allowed to view the %1$d items in this Gallery!' => 'Seuls les utilisateurs inscrits sont autorisés à afficher les %1$d articles de cette galerie !',
'Delete' => 'Supprimer',
'Publish' => 'Publier',
'Unpublish' => 'Dépublier',
'Approve' => 'Accepter',
'Revoke' => 'Révoquer',
'Default setting' => 'Paramètres par défaut',
'Are you sure you want to delete selected item ? The selected item will be deleted and cannot be undone!' => 'Êtes-vous sûr de vouloir supprimer l\'article sélectionné ? L\'article sélectionné sera supprimé et ce sera définitif ! ',
'Max single upload (KB)' => 'Taille maximale pour l\'envoi (Ko)',
'This value can be set by the admin to over-ride the gallery plugin backend default maximum single upload size' => 'Cette valeur peut être fixée par l\'administrateur pour forcer la valeur de la taille max. par défaut pour l\'envoi dans la galerie',
'Updated' => 'À jour',
'Title' => 'Titre',
'Description' => 'Description',
'Download' => 'Télécharger',
'Actions' => 'Actions',
'Never' => 'Jamais',
'Gallery Moderation' => 'Modération de la galerie',
'This tab contains all pending autorization gallery items' => 'Cet onglet contient toutes les articles de la galerie en attente d\'approbation',
'New Gallery Item just uploaded' => 'Un nouvel article vient d\'être envoyée dans la galerie',
/**
 * Parameters available for use in _pg_MSGBODY_NEW language string
 * %1\$s ~ item type
 * %2\$s ~ item title
 * %3\$s ~ item description
 * %4\$s ~ username
 * %5\$s ~ profile link
 */
"A new Gallery item has just been uploaded and may require approval.\n"
."This email contains the item details\n\n"
."Gallery Item Type - %1\$s\n"
."Gallery Item Title - %2\$s\n"
."Gallery Item Description - %3\$s\n\n"
."Username - %4\$s\n"
."Profile Link - %5\$s \n\n\n"
."Please do not respond to this message as it is automatically generated and is for information purposes only\n"
=>
'Un nouvel article vient d\'être envoyé dans la galerie, ce qui peut nécessiter votre approbation.\n"
."Ce message contient les détails de l\'article :\n\n"
."Type de l\'article de galerie - %1\$s\n"
."Titre de l\'article de galerie - %2\$s\n"
."Description de l\'article de galerie - %3\$s\n\n"
."Nom de l\'utilisateur - %4\$s\n"
."Lien vers le profil - %5\$s \n\n\n"
."Prière de ne pas répondre à ce message généré automatiquement uniquement à titre d\'information\n" ',

'Your Gallery Item has been approved!' => 'Votre article de galerie a été approuvé !',

"A Gallery item in your Gallery Tab has just been approved by a moderator.\n\n\n"
."Please do not respond to this message as it is automatically generated and is for information purposes only\n"
=>
"Un article de votre onglet de galerie vient d\'être approuvé par un modérateur.\n\n\n"
."Prière de ne pas répondre à ce message généré automatiquement uniquement à titre d\'information\n",

'Your Gallery Item has been revoked!' => 'Votre article de galerie a été révoqué !',

"A Gallery item in your Gallery Tab has just been revoked by a moderator.\n\n\n"
."If you feel that this action is unjustified please contact one of our moderators.\n"
."Please do not respond to this message as it is automatically generated and is for information purposes only\n"
=>
"Un article de votre onglet de galerie vient d\'être révoqué par un modérateur.\n\n\n"
."Si vous pensez que cette mesure est injustifiée, veuillez contacter l\'un de nos modérateurs.\n"
."Prière de ne pas répondre à ce message généré automatiquement uniquement à titre d\'information\n",

'Your Gallery Item has been deleted!' => 'Votre article de galerie a été supprimé !',

"A Gallery item in your Gallery Tab has just been deleted by a moderator.\n\n\n"
."If you feel that this action is unjustified please contact one of our moderators.\n"
."Please do not respond to this message as it is automatically generated and is for information purposes only\n"
=>
"Un article de votre onglet de galerie vient d\'être supprimé par un modérateur.\n\n\n"
."Si vous pensez que cette mesure est injustifiée, veuillez contacter l\'un de nos modérateurs.\n"
."Prière de ne pas répondre à ce message généré automatiquement uniquement à titre d\'information\n",

'Your Gallery item is pending approval by a site moderator.' => 'Votre article de galerie est en attente d\'approbation par un modérateur du site.',

'Your Gallery item quota has been reached. You must delete an item in order to upload a new one or you may contact the admin to increase your quota.' 
=> 'Le quota d\'articles de votre galerie a été atteint. Vous devez supprimer un article pour pouvoir en envoyer un nouveau, ou vous pouvez contacter l\'administrateur pour augmenter votre quota.',

'Failed to be add index.html to the plugin gallery - please contact administrator!' => 'Impossible d\'ajouter index.html au plugin de galerie - Veuillez contacter l\'administrateur !',
'No item uploaded!' => 'Aucun article envoyé !',
/**
 * Parameters available for use in _pgModeratorViewMessage
 * %1$d ~ Total count of items uploaded
 * %2$d ~ Maximum uploaded items allowed
 * %3$d ~ Total KB of uploaded items
 * %4$d ~ Maximum KB of uploaded items allowed
 * %5$s ~ access mode setting
 * %6$s ~ display format setting
 * %7$s ~ single upload size
 */
'<font color=red>Moderator data:<br />'
.'Items - %1$d<br />'
.'Item Quota - %2$d<br />'
.'Storage - %3$d<br />'
.'Storage Quota - %4$d<br />'
.'Access Mode - %5$s<br />'
.'Display Mode - %6$s<br /></font>'
=>
'<font color=red>Données du modérateur :<br />'
.'Articles - %1$d<br />'
.'Quota d\'articles - %2$d<br />'
.'Espace de stockage - %3$d<br />'
.'Quota de stockage - %4$d<br />'
.'Mode d\'accès - %5$s<br />'
.'Mode d\'affichage - %6$s<br /><br />'
.'Single Upload Size - %7$s<br /></font>',

'Image ' => 'Image ',
' of ' => ' de ',
'Image {x} of {y}' => 'Image (x) de (y)',
/**
 * Following section defines language strings used in CB Gallery Module
 */
'No Viewable Items'        => 'Aucun article visible',
'No items rendered'        => 'Aucun article affiché',
'Edit Gallery Item'        => 'Modifier un élément de la galerie',
'Edit'                     => 'Modifier',
'Update'                   => 'Mettre à jour',
'Bad File - Item rejected' => 'Mauvais fichier - Article rejeté',
'Not logged on'            => 'Non connecté',
'No connected items'       => 'Aucun article d\'une relation directe',
));

// Privacy plugin: (new method: UTF8 encoding here):
CBTxt::addStrings( array(
'Visible on profile'					=>	'Visible dans le profil',
'Only to logged-in users'				=>	'Seulement pour les utilisateurs connectée',
'Only for direct connections'		    =>	'Seulement pour les utilisateurs en relation directe',
'Only for %s'					        =>	'Seulement pour %s',
'Also for connections\' connections'	=>	'Aussi pour les relations directes des relations directes',
'Invisible on profile'					=>	'Invisible dans le profil',
'Access only to logged-in users. Please login.'		=>	'Accès réservé aux utilisateurs connectés. Veuillez vous connecter.',
'Access only to logged-in users. Please login or %s.'	=>	'Accès réservé aux utilisateurs connectés. Veuillez vous connecter ou de %s.',
'register'							=>	's\'inscrire',
'Access only with login'					=>	'Accès uniquement avec un identifiant',
'Access only to directly connected users'			=>	'Accès uniquement aux utilisateurs en relation directe',
'Access only to directly connected users and friends of friends'=>	'Accès uniquement aux utilisateurs en relation directe et aux amis d\'amis',
));

// Activity plugin: (new method: UTF8 encoding here):
CBTxt::addStrings( array(
'%s joined, welcome !'					=>	'%s nous a rejoint, Bienvenue !',
'%s updated his profile'				=>	'%s a mis à jour son profil',
'%s updated their profile'				=>	'%s ont mis à jour leurs profils',

'%s and %s'						=>	'%s et %s',
'%s, %s and %s'						=>	'%s, %s et %s'	,
'%s, %s, %s and %s more'				=>	'%s, %s, %s et %s de plus',

'%s and %s are now connected'			=>	'%s et %s sont maintenant en relation directe',
'%s is now connected to %s'				=>	'%s est maintenant en relation directe avec %s',
'%s are now connected to %s'			=>	'%s sont maintenant en relation directe avec %s',

'%s added a new picture'				=>	'%s a ajouté une nouvelle image',
'%s added new pictures'					=>	'%s a ajouté de nouvelles images',
'%s added %s new pictures'				=>	'%s a ajouté %s nouvelles images',
'%s commented to %s\'s %s'				=>	'%s a commenté sur %s\'s %s',
'%s rated %s\'s %s'					    =>	'%s a évalué %s\'s %s',
'picture'						=>	'image',
'pictures'						=>	'images',
'profile'						=>	'profil',

'%s added a new gallery'				=>	'%s a ajouté une nouvelle galerie',

'%s signed the guestbook of %s'			=>	'%s a signé le livre d\or de %s',
'%s wrote on the wall of %s'			=>	'%s a écrit sur le mur de %s',
'%s posted a new note to %s'			=>	'%s a posté une remarque sur %s',
'%s updated a %s in %s'					=>	'%s a mis à jour un %s dans %s',
'%s updated a %s in %s\'s %s'			=>	'%s a mis à jour un %s dans %s\'s %s',
'%s updated a %s in the %s'				=>	'%s a mis à jour un %s dans la %s',

'%s wrote a new %s'				        =>	'%s a écrit un nouvelle %s',
'%s wrote a new %s "%s"'				=>	'%s a écrit un nouvelle %s "%s"',
'%s replied to %s'					    =>	'%s a répondu sur %s',
'%s replied to %s "%s"'					=>	'%s a répondu sur %s "%s"',
'%s edited his %s'					    =>	'%s a édité son %s',
'forum post'						    =>	'message du forum',
'comment'						        =>	'commentaire',
'note'							        =>	'remarque',
'tag'							        =>	'tag',
'rating'							    =>	'évaluation',

'%s created the group "%s"'				=>	'%s a créé le groupe "%s"',
'%s joined the group "%s"'				=>	'%s a rejoint le groupe "%s"',

'%s subscribed to %s'					=>	'%s s\'est abonné à %s',
'%s upgraded to %s'					    =>	'%s a mis à jour vers %s',
'%s donated %s'						    =>	'%s a donné %s',
'%s donated %s, thank you very much'	=>	'%s a donné %s, merci beaucoup',
'%s donated'						    =>	'%s a donné',
'%s donated, thank you very much'		=>	'%s a donné, merci beaucoup',
'%s purchased something'				=>	'%s a acheté quelque chose',
'%s purchased something, thank you'		=>	'%s a acheté quelque chose, merci',
'%s purchased a %s'				        =>	'%s a acheté un %s',
'%s purchased a %s, thank you'			=>	'%s a acheté un %s, merci',	

));
							
// Ratings fields plugin: (new method: UTF8 encoding here):
CBTxt::addStrings( array(
'Thank you for rating!'					=> 'Merci d\'avoir mis une note !',
'Click on a star to rate!'				=> 'Cliquez sur une étoile pour mettre une note !',
// Rate 1 Star:
'Rate %s %s'							=> 'Taux %s %s',
'Cancel Rating'							=> 'Annuler la note',
// following rating strings can be used/changed in field's param
'Self'									=> 'auto',
'Visitor'								=> 'Visiteur',
'Rating'								=> 'Évaluation',
'Star'									=> 'Étoile',
'Stars'									=> 'Étoiles',
'Poorest'								=> 'Très mauvais',
'Poor'									=> 'Mauvais',
'Average'								=> 'Moyen',
'Good'									=> 'Bien',
'Better'								=> 'Très bien',
'Best'									=> 'Excellent',
));


// Forum integration plugin:
CBTxt::addStrings( array(
'Found %s Forum Posts'					 =>'%s messages trouvé sur le Forum',
'Forum Posts'							 =>'Messages du Forum',
'Last %s Forum Posts'					 =>'Les %s derniers messages',
'Moderator'								 =>'Modérateur',
'Administrator'					         =>'Administrateur',
'ONLINE'								 =>'EN LIGNE',
'OFFLINE'								 =>'HORS LIGNE',
'Online Status: '						 =>'Statut de présence: ',
'View Profile: '						 =>'Voir le profil: ',
'Send Private Message: '				 =>'Envoyer un message privé: ',
'Date'									 => 'Date',
'Subject'								 => 'Sujet',
'Category'								 => 'Categorie',
'Hits'									 => 'Hits',
'Karma: '								 => 'Karma: ',
'Posts: '								 => 'Messages: ',
'Forum Statistics'				         => 'Les statistiques du Forum',
'Forum Ranking'							 =>'Rang sur le Forum',
'Total Posts'							 =>'Nombre de messages',
'Karma'									 =>'Karma',
'No matching forum posts found.'		 =>'Aucun message correspondant n\a été trouvé .',
'This user has no forum posts.'			 =>'Pas de message disponible pour ce membre.',
'Your Subscriptions'					 =>'Vos abonnnements',
'Action'								 =>'Action',
'No subscriptions found for you.'		 =>'Pas d\'abonnement en cours.',
'Your Favorites'						 =>'Vos Favoris',
'No favorites found for you.'			 =>'Pas de favori enregistré.',
'Remove'								 =>'Supprimer',
'Remove All'						     =>'Tout supprimer',
'Unsubscribe'							 =>'Se désabonner',
'Unsubscribe All'						 =>'Supprimer tous les abonnements',
'Are you sure you want to unsubscribe from this forum subscription?'     =>'êtes-vous sûr de vouloir supprimer cet abonnement?',
'Are you sure you want to unsubscribe from all your forum subscriptions?'=>'êtes-vous sûr de vouloir supprimer tous les abonnements?',
'Are you sure you want to remove this favorite thread?'                  =>'êtes-vous sûr de vouloir supprimer ce favori?',
'Are you sure you want to remove all your favorite threads?'             =>'êtes-vous sûr de vouloir supprimer tous les favoris?',
'The forum component is not installed.  Please contact your site administrator.'=>'Le composant de Forum n\est pas disponible. Merci de contacter l\'administrateur du site.',
'Male'									 =>'Homme',
'Female'								 =>'Femme'
));

// Facebook integration plugin:
CBTxt::addStrings( array(
'Facebook' => 'Facebook',
'Synced from Facebook; do not change here, but at Facebook as: %s'=>'La synchronisation de Facebook ne modifie rien ici; mais sur Facebook comme: %s',
'Profile Image'	                   =>'Image du profil',
'First, Middle, and Last Name'     =>'Prénom,second prénom et nom',
'First Name'		           =>'Prénom',
'Last Name'                        =>'Nom',
'About Me'                         =>'À propos de moi',
'Activities'                       =>'Activités',
'Birthday'                         =>'Anniversaire',
'Favorite Books'                   =>'Mes livres favoris',
'Country'                          =>'Pays',
'State'                            =>'État',
'City'                             =>'Ville',
'Zip'                              =>'Code postal',
'Interests'                        =>'Centres d\'intérêt',
'Looking For'                      =>'À la recherche de',
'Interested In'                    =>'Intéressé par',
'Favorite Movies'                  =>'Films favoris',
'Favorite Music'                   =>'Musiques favorites',
'Political View'                   =>'Opinion Politique',
'Favorite Quotes'                  =>'Citations favorites',
'Relationship Status'              =>'Situation sentimental',
'Religious Views'                  =>'Opinion Religieuse',
'Sex'                              =>'Sexe',
'Status'                           =>'Situation',
'Favorite TV Shows                '=>'Emissions TV préférées',
'View Facebook Profile'	           =>'Voir le profil Facebook',
'Connect this account to your Facebook account' =>'Lier ce compte à votre compte Facebook',
'Link'                             =>'Lien',
'Login with your Facebook account' =>'Connexion avec votre compte Facebook',
'Sign in'                          =>'Identifiez-vous',
'Are you sure you want to unlink this account from your Facebook account?'=>'Êtes-vous de vouloir supprimer le lien vers votre compte Facebook?',
'Unlink this account from your Facebook account'=>	'Supprimer le lien vers votre compte Facebook',
'Unlink'                           =>'Supprimer le lien',
'Please change your password from profile edit before unlinking to allow further login after unlinked.'	=>'Veuillez modifier votre mot de passe depuis votre profil avant de supprimer le lien afin de pouvoir vous connecter à nouveau',
'Please change your email from profile edit before unlinking to allow further login after unlinked.'=>'Veuillez modifier votre adresse courriel de profil avant de vous déconnecter pour la prochaine connexion',
'Would you like to do this now?'		=>	'Souhaitez-vous le faire maintenant?',
'Facebook account successfully unlinked!'	=>	'Les paramètres du compte Facebook ont été supprimé avec succès',
'Facebook account successfully linked!'		=>	'Les paramètres du compte Facebook ont été chargé avec succès!',
'Facebook credentials failed to load.'		=>	'Échec de chargement des paramètres du compte Facebook.',
'Error %s: %s'					=>	'Erreur %s: %s',
));
// Twitter integration plugin:
CBTxt::addStrings( array(
'Twitter'							=>	'Twitter',
'Synced from Twitter; do not change here, but at Twitter as: '  =>	'La synchronisation de Twitter ne modifie rien ici; mais sur Twitter comme: ',
'Picture'						        =>	'Image',
'Name'								=>	'Nom',
'View Twitter Profile'					        =>	'Voir le profil Twitter',
'Connect this account to your Twitter account'		        =>	'Lier ce compte à votre compte Twitter',
'Link'								=>	'Lien',
'Login with your Twitter account'				=>	'Connexion avec votre compte Twitter',
'Sign in'							=>	'Identifiez-vous',
'Are you sure you want to unlink this account from your Twitter account?'=>'Êtes-vous de vouloir supprimer le lien vers votre compte Twitter?',
'Unlink this account from your Twitter account'		        =>	'Supprimer le lien vers votre compte Twitter',
'Unlink'							=>	'Supprimer le lien',
'Please change your password from profile edit before unlinking to allow further login after unlinked.'	=>'Veuillez modifier votre mot de passe de profil avant de vous déconnecter pour la prochaine session.',
'Please change your email from profile edit before unlinking to allow further login after unlinked.'	=>'Veuillez modifier votre adresse courriel de profil avant de vous déconnecter pour la prochaine session',
'Would you like to do this now?'				=>	'Souhaitez-vous le faire maintenant?','Twitter account successfully unlinked!'			=>	'Les paramètres du compte Twitter ont été supprimé avec succès!',
'Twitter account successfully linked!'				=>	'Les paramètres du compte Twitter ont été chargé avec succès!',
'Twitter credentials failed to load.'				=>	'Échec de chargement des paramètres du compte Twitter.'
));
// Facebook integration plugin: (updated for version 1.2 of Facebook plugin)
CBTxt::addStrings( array(
// 8 language strings from file plug_cbfacebookconnect/cb.facebookconnect.php
'View Facebook Profile'	             =>	'Voir votre profil Facebook',
'Logout of your Facebook account.'   =>	'Déconnexion de votre compte Facebook.',
'Sign out'	                     =>	'Se déconnecter',
'Login with your Facebook account.'  =>	'Connexion avec votre compte Facebook.',
'Sign in'	                     =>	'Se connecter',
'Unjoin this site'	             =>	'Annuler l\'adhésion à ce site',
'Unauthorize this site from your Facebook account.'	=>	'Interdire ce site à partir de votre compte Facebook.',
'Are you sure you want to unjoin %s?'=>	'Êtes-vous sûr de vouloir annuler l\'adhésion au site %s?'
));

// Twitter integration plugin: (updated for version 1.1 of Twitter plugin)
CBTxt::addStrings( array(
// 3 language strings from file plug_cbtwitter/cb.twitter.php
'View Twitter Profile'	=>	'Voir le profil Twitter',
'Logout of your Twitter account.'	=>	'Déconnexion de votre compte Twitter.',
'Login with your Twitter account.'	=>	'Connexion avec votre compte Twitter.'
));

// imagetoolbox messages needed for CB Team plugins
CBTxt::addStrings( array(
// 1 language string from imagetoolbox
'The file exceeds the maximum size of %s kilobytes' => '!Le fichier dépasse la taille maximum de %s kilobytes',
));
// CB 1.4 missing strings by Anubis
// file cb.validator.php
CBTxt::addStrings( array(
'This field is required.'	=> 'Ce champ est obligatoire',
'Please fix this field.'	=> 'Veuillez corriger ce champ',
'Please enter a valid email address.'	=> 'Veuillez fournir une adresse courriel valide.',
'Please enter a valid URL.'	=> 'Veuillez fournir une URL valide.',
'Please enter a valid date.'	=> 'Veuillez fournir une date valide.',
'Please enter a valid date (ISO).'	=> 'Veuillez fournir une date (ISO) valide.',
'Please enter a valid number.' => 'Veuillez fournir un nombre valide.',
'Please enter only digits.'	=> 'Ne saisissez que des chiffres',
'Please enter a valid credit card number.'	=> 'Veuillez fournir un numéro de carte de crédit valide',
'Please enter the same value again.'	=> 'Ressaisissez la même valeur.',
'Please enter a value with a valid extension.'	=> 'Saisissez une valeur avec extension valide.',
'Please enter no more than {0} characters.'	=> 'Ne saisissez pas plus de {0} caractères.',
'Please enter at least {0} characters.'	=> 'Saisissez au moins {0} caractères.',
'Please enter a value between {0} and {1} characters long.'	=> 'Saisissez entre {0} et {1} caractères.',
'Please enter a value between {0} and {1}.'	=> 'Saisissez une valeur entre {0} et {1}.',
'Please enter a value less than or equal to {0}.'	=> 'Saisissez une valeur inférieure ou égale à {0}.',
'Please enter a value greater than or equal to {0}.'	=> 'Saisissez une valeur supérieure ou égale à {0}.',
));
// CB 1.8 missing strings by yann.fr : https://www.joomlapolis.com/forum/192-cb/173092-traduction-cb-17?limit=6&start=6
CBTxt::addStrings( array(
'No changes.' => 'Pas de changement.',
'Not a valid input' => 'Saisie invalide.',
));

// ========================
// CB Conditional integration plugin:
// ========================

CBTxt::addStrings( array(
// admin.cbconditional.html.php
	'Registration' => 'Inscription',
	'Please note Step by Step requires CB to use DIV layout (table-less).' => 'Veuillez noter que le mode pas à pas requiert une configuration de CB en mode sans tableaux (utiliser les modèles DIV)',
	'Step by Step' => 'Pas à pas',
	'Enable or disable Registration step by step. Step by step allows fields display based off tabs in steps (If tab has 10 fields those 10 fields will be displayed in that step). Step titles all prefix with _REG_STEP followed by their count (e.g. _REG_STEP1) that can be defined within language strings (otherwise will display as Step 1, etc..). Tab registration order as defined in Tab Management during tab edit determines order of steps.' => 'Active/désactive l\'inscription en mode "pas à pas". Le mode pas à pas permet l\'affichage des champs en onglets par étapes (si un onglet possède 10 champs, ces 10 champs seront affichés à cette étape). Les titres des étapes sont préfixés par _REG_STEP suivi par leur numéro d\'ordre (ex. _REG_STEP1) pouvant être définies en tant que chaînes de langue (par défaut Étape 1, etc.). L\'ordre des onglets définis en gestion des onglets en modification des onglets détermine l\'ordre des étapes',
	'Template' => 'Gabarit',
	'Select template to be used on step by step Registration. If template is incomplete then missing files will be used from the default template. Template files can be located at the following location: [rel_path]/templates/' => 'Choix du gabarit à utiliser en inscription pas à pas. Si le gabarit est incomplet, les fichiers manquants seront pris dans le gabarit par défaut. Les gabarits sont accessibles à l\'emplacement: [rel_path]/templates/',
	'Validate' => 'Validation',
	'Enable or disable step Validation. Validate will cause input validation before proceeding to next/previous step (e.g. username is required and click to Step 2 from Step 1 will cause validation error).' => 'Active/désactive la validation pas à pas. La validation pas à pas provoque la validation complète d\'une étape avant de passer à la suivante/précédente (ex. identifiant obligatoire et un clic vers étape 2 provoque une erreur de validation de cette étape).',
// admin.cbconditional.php
	'Config failed to bind! Error: [error]' => 'Échec en liaison de la configuration. Erreur: [error]',
	'Config saved successfully!' => 'Configuration enregistrée avec succès.',
	':: Community Builder :: Table layout configured with step by step enabled - [cb_url]' =>  ':: Community Builder :: Mode tableau configuré alors que le mode pas à pas est actif - [cb_url]',
	':: Config :: DIV layout configured with step by step disabled - [config_url]' => ':: Config :: Mode Community Builder DIV configuré alors que le mode pas à pas est désactivé - [config_url]',
	':: Config :: Registration is not validated on a step by step process and only validated upon submit - [config_url]' => ':: Config :: L\'inscription est en mode pas à pas et la validation par étapes n\'est pas activée. La validation est réalisée en finalisation uniquement - [config_url]',
	':: Tab :: Missing field - [field]' => ':: Onglet :: Champ manquant - [field]',
	':: Tab :: Operator equal to empty value; operator empty suggested - [empty]' => ':: Onglet :: Opérateur retourne une valeur vide; opérateur vide suggéré - [empty]',
	':: Tab :: Operator not equal to empty value; operator not empty suggested - [notempty]' => ':: Onglet :: Opérateur non égal à une valeur vide; opérateur non vide suggéré - [notempty]',
	':: Tab :: Is showing its self - [showself]' => ':: Onglet :: L\'onglet s\'affiche lui même - [showself]',
	':: Tab :: Is hiding its self - [hideself]' => ':: Onglet :: L\'onglet se cache lui-même - [hideself]',
	':: Field :: Missing show and/or hide - [showhide]' => ':: Champ :: Il manque une définition Afficher et/ou cacher - [showhide]',
	':: Field :: Operator equal to empty value; operator empty suggested - [empty]' => ':: Champ :: Opérateur égal à une valeur vide; opérateur vide suggéré - [empty]',
	':: Field :: Operator not equal to empty value; operator not empty suggested - [notempty]' => ':: Champ :: Opérateur non égal à une valeur vide; opérateur non vide suggéré - [notempty]',
	':: Field :: Is showing its self - [showself]' => ':: Champ :: Le champ s\'affiche lui-même - [showself]',
	':: Field :: Is hiding its self - [hideself]' => ':: Champ :: Le champ se cache lui-même - [hideself]',
// field.cbconditional.php
	'- Select Fields -' => '- Champs -',
	'- Select Field -' => '- Champ -',

// plugin.cbconditional.php
// Tabs titles for step by step
	'_REG_STEP1' => 'Étape 1',
	'_REG_STEP2' => 'Étape 2',
	'_REG_STEP3' => 'Étape 3',
	'_REG_STEP4' => 'Étape 4',
	'_REG_STEP5' => 'Étape 5',
	'_REG_STEP6' => 'Étape 6',
	'_REG_STEP7' => 'Étape 7',
	'_REG_STEP8' => 'Étape 8',
	'_REG_STEP9' => 'Étape 9',
	'Step ' => 'Étape '
) ) ;

// IMPORTANT WARNING: The closing tag, "?" and ">" has been intentionally omitted - CB works fine without it.
// This was done to avoid errors caused by custom strings being added after the closing tag. ]
// With such tags, always watchout to NOT add any line or space or anything after the "?" and the ">".
