<?php
/**
 * @version $Id: acctexp.php
 * @package AEC - Account Control Expiration - Membership Manager
 * @subpackage Main Backend Proxy
 * @copyright 2012 Copyright (C) David Deutsch
 * @author David Deutsch <skore@valanx.org> & Team AEC - http://www.valanx.org
 * @license GNU/GPL v.3 http://www.gnu.org/licenses/gpl.html or, at your option, any later version
 */

// no direct access
( defined('_JEXEC') || defined( '_VALID_MOS' ) ) or die( 'Restricted access' );

require_once( JPATH_SITE . '/administrator/components/com_acctexp/admin.acctexp.php' );

?>
