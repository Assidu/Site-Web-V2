<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>
<h1><?php echo $this->title; ?></h1>
<div class="page">
	<?php echo $this->menu; ?>
</div>